# Bruteforce facebook

# work in Python 2.7

# How To Install 

# git clone https://github.com/NeloF4/Bruteforcefb.git

# cd Bruteforcefb

# python2 Brutefb.py

# enjoy
